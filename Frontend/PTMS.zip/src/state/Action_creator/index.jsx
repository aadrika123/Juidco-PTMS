export const Upload_image = (data) => {
  return {
    type: "UPLOAD_IMAGE",
    payload: data,
  };
};
